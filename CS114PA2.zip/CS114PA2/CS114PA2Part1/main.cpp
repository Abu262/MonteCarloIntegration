#define _USE_MATH_DEFINES

#include <iostream>
#include <math.h>       /* exp */
#include <random>
//#include <string>     // std::string, std::to_string
#include <math.h>
#include <chrono>
using namespace std;



//TASK 1-1
//////////////////////////////////////
double Task1Helper(double x)
{
	double y = exp(-(x * x) / 2.0);
	//std::cout << y << std::endl;
	return y;
}

void Task1()
{

	std::random_device rd;  //Will be used to obtain a seed for the random number engine
	std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
	std::uniform_real_distribution<> dis(-2.0, 2.0);
	
	double I = 0.0;		//sample mean
	double S = 0.0;	//scaled deviation
	double s = 0.0;
	double p = 0.25;
	const int N = 100000;
	double Ij[N];   //Ij
	printf("%6s | %6s| %6s |\n", "Round", "I", "S");
	for (int y = 0; y < 10; y++)
	{
		I = 0.0;		//sample mean
		S = 0.0;	//scaled deviation
		s = 0.0;
		p = 0.25;
		for (int i = 0; i < N; i++)
		{
			double x = dis(gen);
			Ij[i] = (Task1Helper(x) / p);
			I = I + Ij[i];

		}
		I = I / N;
		double sum = 0.0;
		for (int i = 0; i < N; i++)
		{
			sum += powf((Ij[i] - I), 2.0);
		}
		s = sqrtf(sum / (N - 1));
		S = (2 * s) / sqrt(N);
		printf("-------------------------\n");
		printf("%6i | %6.3f| %6.3f |\n", y + 1, I, S);
	}

}
//////////////////////////////////////

//TASK 1-2
//////////////////////////////////////
void Task1_2(double Y)
{
	double I = 0.0;		//sample mean
	double S = 0.0;	//scaled deviation
	double s = 0.0;
	double p;// = 0.25;
	const int N = 100000;
	double Ij[N];   //Ij
	std::random_device rd;  //Will be used to obtain a seed for the random number engine
	std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
	std::uniform_real_distribution<> dis(0.0, 1.0);
	double ep;
	printf("%6s | %6s| %6s |\n", "Round", "I", "S");
	for (int y = 0; y < 10; y++)
	{
		
		I = 0.0;		//sample mean
		S = 0.0;	//scaled deviation
		s = 0.0;

		for (int i = 0; i < N; i++)
		{
			ep = dis(gen);
			//std::cout << ep << std::endl;
			double x = 1.0 - (log(ep) / Y);
			p = Y * exp(-Y * (x - 1.0));
			Ij[i] = exp((-(x * x) / 2.0)) / p;
			I = I + Ij[i];
		}
		I = I / N;
		double sum = 0.0;
		for (int i = 0; i < N; i++)
		{
			sum += powf((Ij[i] - I), 2.0);
		}
		s = sqrtf(sum / (N - 1));
		S = (2 * s) / sqrt(N);
		printf("-------------------------\n");
		printf("%6i | %6.3f| %6.3f |\n", y + 1, I, S);
	}
}
//////////////////////////////////////

//TASK 2-1
//////////////////////////////////////
void Task2()
{
	std::random_device rd;  //Will be used to obtain a seed for the random number engine
	std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
	std::uniform_real_distribution<> dis(0.0, 1.0);
	double I = 0.0;		//sample mean
	double S = 0.0;	//scaled deviation
	double s = 0.0;
	double p = 0.25;
	const int N = 100000;
	double Ij[N];   //Ij
	printf("%6s | %6s| %6s |\n", "Round", "I", "S");
	for (int y = 0; y < 10; y++)
	{
		I = 0.0;		//sample mean
		S = 0.0;	//scaled deviation
		s = 0.0;
		
		for (int i = 0; i < N; i++)
		{
			double ep1 = dis(gen);
			double ep2 = dis(gen);
			double x = (M_PI / 2.0)*ep1;
			p = 1/((2.0 * M_PI) * (M_PI/2.0));// ((2.0 * M_PI) *((M_PI / 2.0)));
			    //((M_PI/2 * (M_PI * 2)));
			Ij[i] = sin(x)/p;// / p);
			I = I + Ij[i];
		}
		I = I / N;
		double sum = 0.0;
		for (int i = 0; i < N; i++)
		{
			//		Ij[i] = (Task1() / p);
			sum += powf((Ij[i] - I), 2.0);
		}
		s = sqrtf(sum / (N - 1));
		S = (2 * s) / sqrtf(N);
		printf("-------------------------\n");
		printf("%6i | %6.3f| %6.3f |\n", y + 1, I, S);
	}
}
//////////////////////////////////////


//TASK 2-2
//////////////////////////////////////
double Task2_2Helper(double ep1,double ep2)
{


	//double x[2] = { (M_PI / 2)*ep1, 2.0 * M_PI * ep2 };
	return powf(cos(acos(ep1)) * sin(acos(ep1)) * cos(2 * M_PI*ep2),2.0) ;
}

void Task2_2()
{
	std::random_device rd;  //Will be used to obtain a seed for the random number engine
	std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
	std::uniform_real_distribution<> dis(0.0, 1.0);


	double I = 0.0;		//sample mean
	double S = 0.0;	//scaled deviation
	double s = 0.0;
	double p = 1/(2*M_PI);
	const int N = 100000;
	double Ij[N];   //Ij
	printf("%6s | %6s| %6s |\n", "Round", "I", "S");
	for (int y = 0; y < 10; y++)
	{
		I = 0.0;		//sample mean
		S = 0.0;	//scaled deviation
		s = 0.0;
		//p = 0.25;
		for (int i = 0; i < N; i++)
		{
			double ep1 = dis(gen);
			double ep2 = dis(gen);
			Ij[i] = (Task2_2Helper(ep1,ep2))/p;// / p);
			I = I + Ij[i];
		}
		I = I / N;
		double sum = 0.0;
		for (int i = 0; i < N; i++)
		{
			//		Ij[i] = (Task1() / p);
			sum += powf((Ij[i] - I), 2.0);
		}
		s = sqrtf(sum / (N - 1));
		S = (2 * s) / sqrt(N);
		printf("-------------------------\n");
		printf("%6i | %6.3f| %6.3f |\n", y + 1, I, S);
	}
}
//////////////////////////////////////


//TASK 3
//////////////////////////////////////
bool intersect(double rd[3], double ro[3], double sc[3], double sr)
{
	
	double L[3] = {sc[0] - ro[0], sc[1] - ro[1],  sc[2] - ro[2]};//s.center - r.origin;
	
	//get lengths
	double lL = sqrt((L[0] * L[0]) + (L[1] * L[1]) + (L[2] * L[2]));
	double lrd = sqrt((rd[0] * rd[0]) + (rd[1] * rd[1]) + (rd[2] * rd[2]));


	double angle = acos(((L[0] * rd[0]) + (L[1] * rd[1]) + (L[2] * rd[2]))/(lL*lrd));
	if (angle <= 0.0)
	{
	
		return false;
	}
	double d = sin(angle) * lL;

	if (d < sr)// && d > -sr)
	{

		return true;
	}
	return false;
}

void Task3()
{
	std::random_device rd;  //Will be used to obtain a seed for the random number engine
	std::mt19937 gen(rd()); //Standard mersenne_twister_engine seeded with rd()
	std::uniform_real_distribution<> dis(0.0, 1.0); //omega stuff
	std::uniform_real_distribution<> disXY(-0.5, 0.5); //omega stuff


	double I = 0.0;		//sample mean
	double S = 0.0;	//scaled deviation
	double s = 0.0;
	double p = 1 / (M_PI * M_PI);
	const int N = 25000000;

	printf("%6s | %6s| %6s |\n", "Round", "I", "S");
	for (int y = 0; y < 10; y++)
	{
		int bad = 0;
		int good = 0;
		I = 0.0;		//sample mean
		S = 0.0;	//scaled deviation
		s = 0.0;

		double sum = 0.0;
		double sumsq = 0.0;
		for (int i = 0; i < N; i++)
		{
			double ep1 = dis(rd);
			double ep2 = dis(rd);
			
			double w[2] = { (M_PI/2) * ep1,
							 2 * M_PI*ep2 };

			double rayDir[3] = { sin(w[0]) * cos(w[1]), 
							   	 sin(w[0]) * sin(w[1]), 
								 cos(w[0]) };

			double rayOrg[3] = { disXY(rd), 
								 disXY(rd), 
								 0.0 };
			
			double sphereCenter[3] = {1.0,1.0,5.0};
			double sphereRad = 1.0;
			double answer;
			if (intersect(rayDir, rayOrg, sphereCenter, sphereRad))
			{

				answer = 100 * cos(w[0]) * (M_PI * M_PI);

				I = I + answer;//100 * cos(w[0]) * (M_PI * M_PI);//Ij[i];    //add the new I to the sum
			}
			else
			{

				answer = 0.0;
			}

			sum += answer;
			sumsq += answer * answer;
		
		}
		I = I / N;    //get the average
		double total = 0.0;

		total = sumsq - 2 * I * sum + (I*I*N);
		s = sqrtf(total / (N - 1));
		S = (2 * s) / sqrt(N);
		printf("-------------------------\n");
		printf("%6i | %6.3f| %6.3f |\n", y + 1, I, S);

	}
}
//////////////////////////////////////


int main()
{
	printf("\nTask1\n");
	Task1();
	printf("\nTask1_2\n");
	printf("Y = 0.1\n");
	Task1_2(0.1);
	printf("Y = 1.0\n");
	Task1_2(1.0);
	printf("Y = 10.0\n");
	Task1_2(10.0);
	printf("1.0 is the most efficient");
	printf("\nTask2\n");
	Task2();
	printf("\nTask2_2\n");
	Task2_2();
	printf("\nTask3\n");
	Task3();
	return 0;
}